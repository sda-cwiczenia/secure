package com.sda.secure.model;

public enum CategoryEnum {
    IT, SPORT, MUZYKA
}
